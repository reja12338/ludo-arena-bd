"use client";

import { FormEvent, useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Method = { code: string; label: string; merchant_number: string; instructions: string };
export default function WalletPage() {
  const supabase = createClient();
  const [methods, setMethods] = useState<Method[]>([]);
  const [method, setMethod] = useState("");
  const [amount, setAmount] = useState("100");
  const [sender, setSender] = useState("");
  const [txn, setTxn] = useState("");
  const [message, setMessage] = useState("");
  const [balance, setBalance] = useState<number | null>(null);

  useEffect(() => {
    async function load() {
      const { data } = await supabase.from("payment_methods").select("code,label,merchant_number,instructions").eq("enabled", true);
      setMethods(data ?? []);
      if (data?.length) setMethod(data[0].code);
      const { data: userData } = await supabase.auth.getUser();
      if (userData.user) {
        const { data: wallet } = await supabase.rpc("wallet_balance");
        if (typeof wallet === "number") setBalance(wallet);
      }
    }
    load();
  }, [supabase]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setMessage("");
    const parsed = Number(amount);
    if (!Number.isFinite(parsed) || parsed < 10 || parsed > 50000) {
      setMessage("১০ থেকে ৫০,০০০ টাকার মধ্যে পরিমাণ দিন।");
      return;
    }
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) {
      setMessage("আগে লগইন করুন।");
      return;
    }
    const { error } = await supabase.from("payment_claims").insert({
      user_id: userData.user.id,
      provider: method,
      amount_paisa: Math.round(parsed * 100),
      sender_phone: sender,
      transaction_id: txn.trim()
    });
    setMessage(error ? "আবেদন জমা হয়নি: " + error.message : "আবেদন জমা হয়েছে। যাচাই শেষ না হওয়া পর্যন্ত ব্যালেন্স যোগ হবে না।");
    if (!error) { setTxn(""); setSender(""); }
  }

  async function withdraw(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const amountBDT = Number(form.get("withdrawAmount"));
    const payoutMethod = String(form.get("payoutMethod") || "");
    const payoutNumber = String(form.get("payoutNumber") || "");
    if (!Number.isFinite(amountBDT) || amountBDT < 50 || amountBDT > 50000) {
      setMessage("৫০ থেকে ৫০,০০০ টাকার মধ্যে উত্তোলনের পরিমাণ দিন।"); return;
    }
    const { error } = await supabase.rpc("request_withdrawal", {
      p_amount_paisa: Math.round(amountBDT * 100),
      p_provider: payoutMethod,
      p_destination: payoutNumber
    });
    setMessage(error ? "উত্তোলনের আবেদন ব্যর্থ: " + error.message : "উত্তোলনের আবেদন জমা হয়েছে। অ্যাডমিন যাচাই করবেন।");
  }

  const selected = methods.find(m => m.code === method);
  return <main className="wrap">
    <a href="/">← হোমপেজ</a><h1>ওয়ালেট ও পেমেন্ট</h1>
    <div className="card">
      <h2>ওয়ালেট ব্যালেন্স</h2>
      <p>{balance === null ? "লগইন করলে ব্যালেন্স দেখা যাবে।" : `৳${(balance / 100).toFixed(2)}`}</p>
      <p className="muted">টাকা জমার আবেদন অ্যাডমিন অনুমোদন করলে ব্যালেন্স আপডেট হবে।</p>
    </div>
    <div className="card" style={{marginTop:16}}>
      <h2>টাকা জমার আবেদন</h2>
      <form onSubmit={submit}>
        <label>পেমেন্ট মাধ্যম</label>
        <select value={method} onChange={e => setMethod(e.target.value)} required>
          {methods.map(m => <option key={m.code} value={m.code}>{m.label}</option>)}
        </select>
        {selected && <div className="notice">
          <p>মার্চেন্ট নম্বর: <strong>{selected.merchant_number}</strong></p>
          <p>{selected.instructions}</p>
        </div>}
        <label>পরিমাণ (টাকা)</label><input type="number" min="10" max="50000" value={amount} onChange={e => setAmount(e.target.value)} required />
        <label>যে নম্বর থেকে পাঠিয়েছেন</label><input value={sender} onChange={e => setSender(e.target.value)} pattern="01[3-9][0-9]{8}" placeholder="01XXXXXXXXX" required />
        <label>Transaction ID</label><input value={txn} onChange={e => setTxn(e.target.value)} maxLength={100} required />
        <button disabled={!selected}>যাচাইয়ের জন্য জমা দিন</button>
      </form>
    </div>
    <div className="card" style={{marginTop:16}}>
      <h2>টাকা তোলার আবেদন</h2>
      <form onSubmit={withdraw}>
        <label>পরিমাণ (টাকা)</label><input name="withdrawAmount" type="number" min="50" max="50000" required />
        <label>মাধ্যম</label><select name="payoutMethod" required><option value="bkash">bKash</option><option value="nagad">Nagad</option><option value="rocket">Rocket</option></select>
        <label>প্রাপকের নম্বর</label><input name="payoutNumber" pattern="01[3-9][0-9]{8}" required />
        <button>উত্তোলনের আবেদন</button>
      </form>
      <p className="muted">এই স্টার্টার টাকা স্বয়ংক্রিয়ভাবে পাঠায় না; অ্যাডমিন বহিরাগতভাবে পরিশোধ করবেন।</p>
    </div>
    {message && <p role="status" className="notice">{message}</p>}
  </main>;
}
