"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Claim = { id: string; provider: string; amount_paisa: number; sender_phone: string; transaction_id: string; created_at: string; user_id: string };
type Withdrawal = { id: string; user_id: string; provider: string; amount_paisa: number; destination: string; created_at: string };
export default function AdminPage() {
  const supabase = createClient();
  const [claims, setClaims] = useState<Claim[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [message, setMessage] = useState("অ্যাডমিন হিসেবে লগইন করুন।");
  const [busy, setBusy] = useState(false);

  async function load() {
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) { setMessage("অ্যাডমিন পেজ দেখতে লগইন করুন।"); return; }
    const { data: c, error: ce } = await supabase.from("payment_claims")
      .select("id,provider,amount_paisa,sender_phone,transaction_id,created_at,user_id")
      .eq("status", "pending").order("created_at");
    const { data: w, error: we } = await supabase.from("withdrawal_requests")
      .select("id,user_id,provider,amount_paisa,destination,created_at")
      .eq("status", "pending").order("created_at");
    if (ce || we) { setMessage("অ্যাক্সেস নেই অথবা ডেটা লোড হয়নি। নিশ্চিত করুন আপনার অ্যাকাউন্টের admin role আছে।"); return; }
    setClaims(c ?? []); setWithdrawals(w ?? []); setMessage("পেন্ডিং আবেদনগুলো লোড হয়েছে।");
  }

  useEffect(() => { load(); }, []);

  async function reviewClaim(id: string, approve: boolean) {
    setBusy(true);
    const { error } = await supabase.rpc("review_payment_claim", { p_claim_id: id, p_approve: approve });
    setBusy(false);
    setMessage(error ? "কাজ ব্যর্থ: " + error.message : approve ? "পেমেন্ট অনুমোদিত।" : "পেমেন্ট প্রত্যাখ্যাত।");
    await load();
  }

  async function reviewWithdrawal(id: string, action: "paid" | "reject") {
    setBusy(true);
    const { error } = await supabase.rpc("review_withdrawal", { p_request_id: id, p_action: action });
    setBusy(false);
    setMessage(error ? "কাজ ব্যর্থ: " + error.message : "উত্তোলনের স্ট্যাটাস আপডেট হয়েছে।");
    await load();
  }

  return <main className="wrap">
    <a href="/">← হোমপেজ</a><h1>অ্যাডমিন প্যানেল</h1>
    <p className="notice">অনুমোদনের আগে মার্চেন্ট অ্যাকাউন্টে আসল লেনদেন যাচাই করুন। একই TxnID দ্বিতীয়বার অনুমোদন করবেন না।</p>
    <p role="status" className="muted">{message}</p>
    <button onClick={load}>রিফ্রেশ</button>
    <h2>পেমেন্ট যাচাই</h2>
    <div className="grid">
      {claims.map(c => <div className="card" key={c.id}>
        <p>মাধ্যম: {c.provider}</p><p>পরিমাণ: ৳{(c.amount_paisa/100).toFixed(2)}</p>
        <p>প্রেরক: {c.sender_phone}</p><p>TxnID: <code>{c.transaction_id}</code></p>
        <p className="muted">User: {c.user_id}</p>
        <div className="row">
          <button disabled={busy} onClick={() => { if (confirm("মার্চেন্ট রেকর্ডে যাচাই করেছেন?")) reviewClaim(c.id, true); }}>যাচাই করে অনুমোদন</button>
          <button disabled={busy} onClick={() => reviewClaim(c.id, false)}>প্রত্যাখ্যান</button>
        </div>
      </div>)}
      {claims.length === 0 && <p className="muted">পেন্ডিং পেমেন্ট নেই।</p>}
    </div>
    <h2>উত্তোলনের আবেদন</h2>
    <div className="grid">
      {withdrawals.map(w => <div className="card" key={w.id}>
        <p>মাধ্যম: {w.provider}</p><p>পরিমাণ: ৳{(w.amount_paisa/100).toFixed(2)}</p>
        <p>নম্বর: {w.destination}</p><p className="muted">User: {w.user_id}</p>
        <div className="row">
          <button disabled={busy} onClick={() => { if (confirm("বাইরে থেকে টাকা পাঠিয়েছেন এবং রেকর্ড মিলিয়েছেন?")) reviewWithdrawal(w.id, "paid"); }}>পরিশোধ সম্পন্ন</button>
          <button disabled={busy} onClick={() => reviewWithdrawal(w.id, "reject")}>প্রত্যাখ্যান / টাকা ফেরত</button>
        </div>
      </div>)}
      {withdrawals.length === 0 && <p className="muted">পেন্ডিং উত্তোলন নেই।</p>}
    </div>
  </main>;
}
