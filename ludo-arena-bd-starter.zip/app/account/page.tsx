"use client";

import { FormEvent, useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function AccountPage() {
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");

  async function submit(e: FormEvent, mode: "signup" | "login") {
    e.preventDefault();
    setMessage("");
    if (mode === "signup") {
      const { error } = await supabase.auth.signUp({
        email, password, options: { data: { display_name: name } }
      });
      setMessage(error ? error.message : "নিবন্ধন অনুরোধ হয়েছে। ইমেইল কনফার্মেশন চালু থাকলে ইনবক্স দেখুন।");
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      setMessage(error ? error.message : "লগইন সফল। এখন ওয়ালেট পেজে যেতে পারেন।");
    }
  }

  return <main className="wrap">
    <a href="/">← হোমপেজ</a><h1>অ্যাকাউন্ট</h1>
    <div className="card">
      <form onSubmit={e => submit(e, "signup")}>
        <h2>রেজিস্ট্রেশন</h2>
        <label>নাম</label><input value={name} onChange={e => setName(e.target.value)} maxLength={60} required />
        <label>ইমেইল</label><input type="email" value={email} onChange={e => setEmail(e.target.value)} required />
        <label>পাসওয়ার্ড (কমপক্ষে ১২ অক্ষর)</label><input type="password" minLength={12} autoComplete="new-password" value={password} onChange={e => setPassword(e.target.value)} required />
        <button>অ্যাকাউন্ট তৈরি</button>
      </form>
      <hr />
      <form onSubmit={e => submit(e, "login")}>
        <h2>লগইন</h2>
        <label>ইমেইল</label><input type="email" value={email} onChange={e => setEmail(e.target.value)} required />
        <label>পাসওয়ার্ড</label><input type="password" autoComplete="current-password" value={password} onChange={e => setPassword(e.target.value)} required />
        <button>লগইন</button>
      </form>
      {message && <p role="status" className="notice">{message}</p>}
    </div>
  </main>;
}
